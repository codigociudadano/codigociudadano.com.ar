<?php
/**
 * @package Techotronic
 * @subpackage jQuery Colorbox
 *
 * @since 4.1
 * @author Arne Franken
 *
 * Right column for settings page
 */
?>
<div class="postbox-container" style="width: 29%;">
<?php
  require_once 'sp-donations.php';
  require_once 'sp-donate-box.php';
  require_once 'sp-translation.php';
  ?>
</div>