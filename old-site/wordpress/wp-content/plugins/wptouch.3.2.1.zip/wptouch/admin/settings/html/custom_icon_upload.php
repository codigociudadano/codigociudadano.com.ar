<div class="custom-icon-uploader" id="custom_icon_uploader">
	<span class="spinner" style="display:none"></span>
 	<button class="upload button-secondary" id="custom_icon_upload_button"><?php _e( 'Upload Icon', 'wptouch-pro' ); ?></button>
	<div class="progress progress-striped progress-success" style="display: none;" title="<?php _e( 'Upload Complete!', 'wptouch-pro' ); ?>" rel="popover" data-placement="right">
	  <div class="bar" style="width: 20%;"></div>
	</div>

	<br class="clearfix" />
	<span class="upload-desc"><?php _e( 'Ready to upload', 'wptouch-pro' ); ?>&hellip;</span>
	<div id="custom_icon_uploader_spot" style="display: none;"></div>
</div>