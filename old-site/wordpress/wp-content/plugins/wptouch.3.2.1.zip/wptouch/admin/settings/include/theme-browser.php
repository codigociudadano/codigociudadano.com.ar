<?php

require_once( WPTOUCH_DIR . '/core/admin-themes.php' ); 