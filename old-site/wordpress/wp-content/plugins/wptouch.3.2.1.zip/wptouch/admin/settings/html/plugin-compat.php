<div id="plugin-compat-setting" class="nano">
	<div class="content">
		<p><?php _e( 'Your active plugin list is refreshing', 'wptouch-pro' ); ?>&hellip;</p>
	</div>
</div>
