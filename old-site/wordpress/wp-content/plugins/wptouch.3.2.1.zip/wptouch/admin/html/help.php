<h4 id="bnc-help-h4"><?php _e( 'WPtouch Pro Help & Account Links', 'wptouch-pro' ); ?></h4>
<ul id="bnc-help-menu">
	<li><a href="http://www.bravenewcode.com/support/" target="_blank"><?php _e( 'Support Forums', 'wptouch-pro' ); ?></a></li>
	<li><a href="http://www.bravenewcode.com/docs/" target="_blank"><?php _e( 'Documentation', 'wptouch-pro' ); ?></a></li>
	<li><a href="http://www.bravenewcode.com/support/profile/" target="_blank"><?php _e( 'Account & Downloads', 'wptouch-pro' ); ?></a></li>
	<li><a href="http://twitter.com/bravenewcode" target="_blank"><?php _e( 'BraveNewCode on Twitter', 'wptouch-pro' ); ?></a></li>
	<li><a href="http://www.bravenewcode.com/general/terms/" target="_blank"><?php _e( 'Plugin Licensing Terms', 'wptouch-pro' ); ?></a></li>
</ul>