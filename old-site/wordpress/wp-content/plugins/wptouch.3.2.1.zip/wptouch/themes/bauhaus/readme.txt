Theme Name: Bauhaus
Theme URI: http://www.bravenewcode.com/wptouch/
Description: Clean, modern, functional design. Great for all types of WordPress sites.
Version: 1.1
Stable tag: 1.1
Depends on: 3.1
Author: BraveNewCode Inc.
Parent: Foundation
Tags: smartphone