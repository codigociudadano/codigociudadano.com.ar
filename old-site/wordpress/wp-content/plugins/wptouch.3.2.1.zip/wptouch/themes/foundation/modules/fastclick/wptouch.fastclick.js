/* WPtouch Foundation FastClick Code */
jQuery( function() {
    FastClick.attach( document.body );
});