Theme Name: Foundation
Theme URI: http://www.bravenewcode.com/store/plugins/wptouch-pro/
Description: The original WPtouch Pro foundation framework (DO NOT USE DIRECTLY)
Version: 2.0.4
Author: BraveNewCode Inc.