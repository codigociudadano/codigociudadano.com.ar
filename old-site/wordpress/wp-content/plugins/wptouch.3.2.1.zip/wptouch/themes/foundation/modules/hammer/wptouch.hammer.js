/* WPtouch Foundation Hammer Code */

// WPtouch-specific hammer code should go here
function doHammerTime() {

}
	
jQuery( document ).ready( function() { doHammerTime(); } );